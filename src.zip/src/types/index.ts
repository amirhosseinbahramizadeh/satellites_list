export interface Satellite {
  id: number;
  name: string;
  norad_id?: number;
  distance?: number;
  status: 'active' | 'inactive' | 'unknown';
  launch_date?: string;
  orbit?: string;
  type?: string;
}

export interface ApiResponse {
  info: {
    total: number;
  };
  satellites: Satellite[];
}