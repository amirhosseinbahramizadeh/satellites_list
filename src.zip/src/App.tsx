import React, { useState, useEffect } from 'react';
import { fetchSatellites, fetchSatelliteDetails } from './services/api';
import { Satellite } from './types';
import Header from './components/Header';
import SearchBar from './components/SearchBar';
import SatelliteGrid from './components/SatelliteGrid';
import SatelliteDetails from './components/SatelliteDetails';
import LoadingSpinner from './components/LoadingSpinner';

function App() {
  const [satellites, setSatellites] = useState<Satellite[]>([]);
  const [filteredSatellites, setFilteredSatellites] = useState<Satellite[]>([]);
  const [selectedSatellite, setSelectedSatellite] = useState<Satellite | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [refreshTime, setRefreshTime] = useState<Date>(new Date());

  // Fetch satellites on initial load
  useEffect(() => {
    const loadSatellites = async () => {
      try {
        setIsLoading(true);
        const data = await fetchSatellites();
        setSatellites(data.satellites);
        setFilteredSatellites(data.satellites);
        setError(null);
      } catch (err) {
        setError('Failed to fetch satellite data. Please try again later.');
        console.error(err);
      } finally {
        setIsLoading(false);
      }
    };

    loadSatellites();
  }, [refreshTime]);

  // Handle satellite selection
  const handleSelectSatellite = async (id: number) => {
    try {
      setIsLoading(true);
      const satellite = await fetchSatelliteDetails(id);
      setSelectedSatellite(satellite);
    } catch (err) {
      setError('Failed to fetch satellite details. Please try again later.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  // Handle search
  const handleSearch = (query: string) => {
    if (!query.trim()) {
      setFilteredSatellites(satellites);
      return;
    }

    const filtered = satellites.filter(
      (satellite) => satellite.name.toLowerCase().includes(query.toLowerCase())
    );
    setFilteredSatellites(filtered);
  };

  // Handle filter by status
  const handleFilter = (status: string) => {
    if (status === 'all') {
      setFilteredSatellites(satellites);
      return;
    }

    const filtered = satellites.filter(
      (satellite) => satellite.status === status
    );
    setFilteredSatellites(filtered);
  };

  // Handle refresh
  const handleRefresh = () => {
    setRefreshTime(new Date());
  };

  return (
    <div className="min-h-screen pb-12">
      <Header />
      
      <main className="container mx-auto px-4 max-w-6xl animate-fadeIn">
        {error && (
          <div className="bg-red-500/20 border border-red-500 text-white p-4 rounded-lg mb-6">
            {error}
          </div>
        )}

        {selectedSatellite ? (
          <SatelliteDetails 
            satellite={selectedSatellite} 
            onBack={() => setSelectedSatellite(null)} 
          />
        ) : (
          <>
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-white">Satellites in Space</h2>
              <button 
                onClick={handleRefresh}
                className="px-4 py-2 bg-slate-700 text-white rounded-lg hover:bg-slate-600 transition-colors"
              >
                Refresh Data
              </button>
            </div>
            
            <SearchBar onSearch={handleSearch} onFilter={handleFilter} />
            
            {isLoading ? (
              <LoadingSpinner />
            ) : filteredSatellites.length > 0 ? (
              <div className="animate-slideUp">
                <SatelliteGrid 
                  satellites={filteredSatellites} 
                  onSelectSatellite={handleSelectSatellite} 
                />
              </div>
            ) : (
              <div className="text-center py-10 text-slate-400">
                No satellites found. Try a different search term or filter.
              </div>
            )}
          </>
        )}
      </main>
    </div>
  );
}

export default App;