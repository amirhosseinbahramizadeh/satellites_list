import { ApiResponse, Satellite } from '../types';

// This is a sample API endpoint that could be replaced with a real satellite API
const API_URL = 'https://n2yo.com/rest/v1/satellite';
const API_KEY = 'YOUR_API_KEY'; // In a real app, this would be in an env file

// For demo purposes, we'll generate mock data since we don't have a real API key
export const fetchSatellites = async (): Promise<ApiResponse> => {
  // In a real app, you would fetch from the actual API:
  // return fetch(`${API_URL}/above/41.702/-76.014/0/70/18&apiKey=${API_KEY}`)
  //   .then(response => response.json());
  
  // For demo, generate mock data
  return new Promise((resolve) => {
    setTimeout(() => {
      const mockSatellites: Satellite[] = [
        {
          id: 1,
          name: 'International Space Station',
          norad_id: 25544,
          distance: 408,
          status: 'active',
          launch_date: '1998-11-20',
          orbit: 'Low Earth Orbit',
          type: 'Space Station'
        },
        {
          id: 2,
          name: 'Hubble Space Telescope',
          norad_id: 20580,
          distance: 547,
          status: 'active',
          launch_date: '1990-04-24',
          orbit: 'Low Earth Orbit',
          type: 'Telescope'
        },
        {
          id: 3,
          name: 'NOAA-19',
          norad_id: 33591,
          distance: 870,
          status: 'active',
          launch_date: '2009-02-06',
          orbit: 'Sun-synchronous Orbit',
          type: 'Weather'
        },
        {
          id: 4,
          name: 'GPS IIR-21',
          norad_id: 35752,
          distance: 20180,
          status: 'active',
          launch_date: '2009-08-17',
          orbit: 'Medium Earth Orbit',
          type: 'Navigation'
        },
        {
          id: 5,
          name: 'GOES-16',
          norad_id: 41866,
          distance: 35786,
          status: 'active',
          launch_date: '2016-11-19',
          orbit: 'Geostationary Orbit',
          type: 'Weather'
        },
        {
          id: 6,
          name: 'Vanguard 1',
          norad_id: 5,
          distance: 3847,
          status: 'inactive',
          launch_date: '1958-03-17',
          orbit: 'Medium Earth Orbit',
          type: 'Research'
        },
        {
          id: 7,
          name: 'LAGEOS 1',
          norad_id: 8820,
          distance: 5860,
          status: 'active',
          launch_date: '1976-05-04',
          orbit: 'Medium Earth Orbit',
          type: 'Scientific'
        },
        {
          id: 8,
          name: 'Intelsat 901',
          norad_id: 26824,
          distance: 35786,
          status: 'inactive',
          launch_date: '2001-06-09',
          orbit: 'Geostationary Orbit',
          type: 'Communications'
        },
        {
          id: 9,
          name: 'COSMOS 1408 (Debris)',
          norad_id: 13552,
          distance: 480,
          status: 'unknown',
          launch_date: '1982-09-16',
          orbit: 'Low Earth Orbit',
          type: 'Debris'
        }
      ];

      resolve({
        info: {
          total: mockSatellites.length,
        },
        satellites: mockSatellites,
      });
    }, 800); // Add a small delay to simulate network request
  });
};

export const fetchSatelliteDetails = async (id: number): Promise<Satellite> => {
  const { satellites } = await fetchSatellites();
  const satellite = satellites.find(sat => sat.id === id);
  
  if (!satellite) {
    throw new Error('Satellite not found');
  }
  
  return satellite;
};