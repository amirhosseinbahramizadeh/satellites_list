import React from 'react';
import { Satellite } from '../types';
import { formatDistanceUnit } from '../utils/formatters';
import { Orbit, Rocket, AlertCircle } from 'lucide-react';

interface SatelliteCardProps {
  satellite: Satellite;
  onClick: (id: number) => void;
}

const SatelliteCard: React.FC<SatelliteCardProps> = ({ satellite, onClick }) => {
  const statusColor = {
    active: 'bg-green-500',
    inactive: 'bg-red-500',
    unknown: 'bg-yellow-500',
  };

  return (
    <div 
      className="bg-slate-800 rounded-xl overflow-hidden shadow-lg transition-all duration-300 hover:shadow-xl hover:scale-[1.02] cursor-pointer"
      onClick={() => onClick(satellite.id)}
    >
      <div className="p-6">
        <div className="flex justify-between items-start mb-4">
          <h3 className="text-xl font-bold text-white">{satellite.name}</h3>
          <div className={`${statusColor[satellite.status]} h-3 w-3 rounded-full mt-1.5`}></div>
        </div>
        
        <div className="mt-4 space-y-3">
          <div className="flex items-center text-slate-300">
            <Rocket size={16} className="mr-2" />
            <span>ID: {satellite.norad_id || 'N/A'}</span>
          </div>
          
          <div className="flex items-center text-slate-300">
            <Orbit size={16} className="mr-2" />
            <span>
              {satellite.distance ? formatDistanceUnit(satellite.distance) : 'Unknown distance'}
            </span>
          </div>
          
          <div className="flex items-center text-slate-300">
            <AlertCircle size={16} className="mr-2" />
            <span className="capitalize">{satellite.status}</span>
          </div>
        </div>
      </div>
      
      <div className={`h-1.5 w-full ${statusColor[satellite.status]}`}></div>
    </div>
  );
};

export default SatelliteCard;