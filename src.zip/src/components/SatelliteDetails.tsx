import React from 'react';
import { Satellite } from '../types';
import { formatDistanceUnit, formatDate } from '../utils/formatters';
import { ArrowLeft, Calendar, Orbit, Tag, Info, Radio } from 'lucide-react';

interface SatelliteDetailsProps {
  satellite: Satellite;
  onBack: () => void;
}

const SatelliteDetails: React.FC<SatelliteDetailsProps> = ({ satellite, onBack }) => {
  const statusColor = {
    active: 'bg-green-500 text-green-500',
    inactive: 'bg-red-500 text-red-500',
    unknown: 'bg-yellow-500 text-yellow-500',
  };

  const statusBgColor = {
    active: 'bg-green-500/10',
    inactive: 'bg-red-500/10',
    unknown: 'bg-yellow-500/10',
  };

  return (
    <div className="bg-slate-800 rounded-xl overflow-hidden shadow-lg animate-fadeIn">
      <div className="p-6 pb-8">
        <button 
          onClick={onBack}
          className="flex items-center mb-6 text-slate-400 hover:text-white transition-colors"
        >
          <ArrowLeft size={16} className="mr-2" />
          Back to all satellites
        </button>

        <div className="flex flex-col md:flex-row justify-between">
          <div>
            <h2 className="text-2xl font-bold text-white mb-2">{satellite.name}</h2>
            <div className={`inline-flex items-center px-3 py-1 rounded-full ${statusBgColor[satellite.status]} ${statusColor[satellite.status]} text-sm font-medium`}>
              <Radio size={14} className="mr-1.5" />
              <span className="capitalize">{satellite.status}</span>
            </div>
          </div>
        </div>

        <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div className="flex items-start">
              <Info size={20} className="text-slate-400 mt-0.5 mr-3" />
              <div>
                <p className="text-slate-400 text-sm">NORAD ID</p>
                <p className="text-white font-medium">{satellite.norad_id || 'N/A'}</p>
              </div>
            </div>
            
            <div className="flex items-start">
              <Orbit size={20} className="text-slate-400 mt-0.5 mr-3" />
              <div>
                <p className="text-slate-400 text-sm">Distance</p>
                <p className="text-white font-medium">
                  {satellite.distance ? formatDistanceUnit(satellite.distance) : 'Unknown'}
                </p>
              </div>
            </div>
            
            <div className="flex items-start">
              <Calendar size={20} className="text-slate-400 mt-0.5 mr-3" />
              <div>
                <p className="text-slate-400 text-sm">Launch Date</p>
                <p className="text-white font-medium">
                  {satellite.launch_date ? formatDate(satellite.launch_date) : 'Unknown'}
                </p>
              </div>
            </div>
          </div>
          
          <div className="space-y-4">
            <div className="flex items-start">
              <Tag size={20} className="text-slate-400 mt-0.5 mr-3" />
              <div>
                <p className="text-slate-400 text-sm">Type</p>
                <p className="text-white font-medium">{satellite.type || 'N/A'}</p>
              </div>
            </div>
            
            <div className="flex items-start">
              <Orbit size={20} className="text-slate-400 mt-0.5 mr-3" />
              <div>
                <p className="text-slate-400 text-sm">Orbit</p>
                <p className="text-white font-medium">{satellite.orbit || 'N/A'}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SatelliteDetails;