import React from 'react';
import { Satellite } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header className="py-6 mb-8 border-b border-slate-700">
      <div className="container mx-auto px-4 max-w-6xl">
        <div className="flex items-center">
          <Satellite size={28} className="text-blue-500 mr-3" />
          <h1 className="text-2xl font-bold text-white">SatelliteTracker</h1>
        </div>
      </div>
    </header>
  );
};

export default Header;