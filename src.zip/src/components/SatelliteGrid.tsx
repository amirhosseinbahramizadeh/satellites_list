import React from 'react';
import { Satellite } from '../types';
import SatelliteCard from './SatelliteCard';

interface SatelliteGridProps {
  satellites: Satellite[];
  onSelectSatellite: (id: number) => void;
}

const SatelliteGrid: React.FC<SatelliteGridProps> = ({ satellites, onSelectSatellite }) => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
      {satellites.map((satellite) => (
        <SatelliteCard
          key={satellite.id}
          satellite={satellite}
          onClick={onSelectSatellite}
        />
      ))}
    </div>
  );
};

export default SatelliteGrid;