import React, { useState } from 'react';
import { Search, Filter } from 'lucide-react';

interface SearchBarProps {
  onSearch: (query: string) => void;
  onFilter: (status: string) => void;
}

const SearchBar: React.FC<SearchBarProps> = ({ onSearch, onFilter }) => {
  const [query, setQuery] = useState('');
  const [isFilterOpen, setIsFilterOpen] = useState(false);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch(query);
  };

  const handleFilterClick = (status: string) => {
    onFilter(status);
    setIsFilterOpen(false);
  };

  return (
    <div className="mb-8 relative">
      <form onSubmit={handleSearch} className="flex">
        <div className="relative flex-grow">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search size={18} className="text-slate-400" />
          </div>
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="block w-full pl-10 pr-3 py-2.5 bg-slate-700 border border-slate-600 rounded-l-lg text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="Search satellites..."
          />
        </div>
        <button
          type="submit"
          className="px-4 py-2.5 bg-blue-600 text-white rounded-r-lg hover:bg-blue-700 transition-colors"
        >
          Search
        </button>
        <button
          type="button"
          onClick={() => setIsFilterOpen(!isFilterOpen)}
          className="ml-2 px-3 py-2.5 bg-slate-700 text-white rounded-lg hover:bg-slate-600 transition-colors flex items-center"
        >
          <Filter size={18} />
        </button>
      </form>

      {isFilterOpen && (
        <div className="absolute right-0 mt-2 p-2 bg-slate-800 rounded-lg shadow-lg z-10 w-48 border border-slate-700 animate-fadeIn">
          <p className="px-3 py-2 text-sm text-slate-400">Filter by status:</p>
          <button
            onClick={() => handleFilterClick('all')}
            className="w-full text-left px-3 py-2 hover:bg-slate-700 text-white rounded transition-colors text-sm"
          >
            All satellites
          </button>
          <button
            onClick={() => handleFilterClick('active')}
            className="w-full text-left px-3 py-2 hover:bg-slate-700 text-white rounded transition-colors text-sm"
          >
            Active
          </button>
          <button
            onClick={() => handleFilterClick('inactive')}
            className="w-full text-left px-3 py-2 hover:bg-slate-700 text-white rounded transition-colors text-sm"
          >
            Inactive
          </button>
          <button
            onClick={() => handleFilterClick('unknown')}
            className="w-full text-left px-3 py-2 hover:bg-slate-700 text-white rounded transition-colors text-sm"
          >
            Unknown
          </button>
        </div>
      )}
    </div>
  );
};

export default SearchBar;