export const formatDistanceUnit = (distance: number): string => {
  if (distance < 1000) {
    return `${distance} km`;
  } else {
    const distanceInThousands = (distance / 1000).toFixed(1);
    return `${distanceInThousands}k km`;
  }
};

export const formatDate = (dateString: string): string => {
  const options: Intl.DateTimeFormatOptions = { 
    year: 'numeric', 
    month: 'long', 
    day: 'numeric' 
  };
  
  return new Date(dateString).toLocaleDateString('en-US', options);
};